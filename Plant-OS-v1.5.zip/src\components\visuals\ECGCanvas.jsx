import React, { useRef, useEffect } from 'react';

const ECGCanvas = ({
    dataPoints = [], // Array of numbers (y-values)
    speed = 2,
    color = '#10b981', // tailwind green-500 equivalent usually
    height = 100,
    width = 300,
    isRunning = true
}) => {
    const canvasRef = useRef(null);
    const requestRef = useRef();
    const xPosRef = useRef(0);
    const indexRef = useRef(0);

    // Offscreen canvas for double buffering? Not strictly necessary for this simple effect, 
    // but useful if we want to retain the whole history. 
    // However, the "fade" effect requires clearing or drawing a semi-transparent rect over the main canvas.
    // Let's stick to the "Fade Trail" approach:
    // Every frame:
    // 1. Draw a low-opacity black rectangle over the whole canvas (fades old trails).
    // 2. Draw the new line segment from (lastX, lastY) to (currentX, currentY).
    // 3. Increment X. If X > width, wrap around (scanbar effect).

    // Wait, the standard "medical monitor" usually has a "cleaning bar" (a gap) that moves, 
    // OR it overwrites from left to right.
    // The "Fade Trail" is easier to make look "cool" but maybe less "medical standard" than the rewrite bar.
    // However, the user asked for "Realistic (Cinzento e Imperfeito) ... varredura que apaga o rastro antigo enquanto escreve o novo (efeito fade trail)".
    // So "Fade trail" or "Eraser bar".
    // Let's implement the "Eraser Bar" (Scanline) approach as it's more iconic: 
    // A vertical "eraser" moves ahead of the drawing point.

    const lastYRef = useRef(height / 2);

    useEffect(() => {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');

        // Initial opaque fill
        ctx.fillStyle = '#00000000'; // Transparent initially if handled by parent, or black.
        // Actually parent is monitor shell, so transparent is best, but we need to clear previous drawings.
        // Let's assume transparent background and we clear rect.
        ctx.clearRect(0, 0, width, height);

        if (!isRunning) return;

        const animate = () => {
            if (!canvas) return;

            // Speed pixels per frame
            const step = speed;

            // Calculate next X
            let nextX = xPosRef.current + step;

            // Get next Y data
            // dataPoints should be normalized 0-1 or we normalize here.
            // Let's assume dataPoints are 0-100 or already scaled? 
            // Usually simpler if dataPoints are just the signal shape, repeating.

            let val = 50; // default baseline
            if (dataPoints.length > 0) {
                val = dataPoints[indexRef.current % dataPoints.length];
                // If data is regular ECG, it might be y-values. 
                // Let's assume raw values need scaling to fit height.
                // Or user passes pre-scaled data. Let's assume pre-scaled 0-height or centered.
                // Most ECG data arrays are just numbers like -0.5 to 1.5.
            }

            // Map val (approx -1 to 2) to canvas height
            // Center is height/2. Scale factor ~ height/3.
            // Invert Y because canvas Y is down.
            // val = 50 is center? Let's assume data is normalized 0-100.

            // Let's try to infer or just map:
            // Input data from ecgData.js is likely SVG path d="..." strings in the old code.
            // We need an array of numbers now.
            // Limitation: The old code used SVG paths. I might need to sample the SVG path or use a new data source.
            // For now, I will generate a synthetic normal sinus rhythm if dataPoints is empty, OR
            // expect specific simple array data. 

            // To be robust: If dataPoints is not provided, generate a flat line.

            // Scaling logic:
            // Center = height / 2.
            const scaledY = height - ((val / 100) * height); // Simple 0-100 mapping
            // Note: If val is outside 0-100, it clips.

            // Draw "Eraser" ahead
            const eraserWidth = 20;
            ctx.clearRect(nextX, 0, eraserWidth, height); // Clear a strip ahead

            // Draw Line
            ctx.beginPath();
            ctx.lineWidth = 2;
            ctx.strokeStyle = color;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.shadowBlur = 4;
            ctx.shadowColor = color;

            ctx.moveTo(xPosRef.current, lastYRef.current);
            ctx.lineTo(nextX, scaledY);
            ctx.stroke();

            // Wrap around
            if (nextX >= width) {
                nextX = 0;
                xPosRef.current = 0;
                // Move opacity fade? No, we use eraser.
                // Reset X
            } else {
                xPosRef.current = nextX;
            }

            lastYRef.current = scaledY;
            indexRef.current++;

            requestRef.current = requestAnimationFrame(animate);
        };

        requestRef.current = requestAnimationFrame(animate);

        return () => cancelAnimationFrame(requestRef.current);
    }, [width, height, speed, color, dataPoints, isRunning]);

    return (
        <canvas
            ref={canvasRef}
            width={width}
            height={height}
            className="block"
            style={{ width: '100%', height: '100%' }} // Responsive scaling helper
        />
    );
};

export default ECGCanvas;
