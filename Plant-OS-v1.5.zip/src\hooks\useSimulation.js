import { useState, useCallback } from 'react';

export default function useSimulation(scenarioData) {
    // Initialize state with a deep clone
    const [gameState, setGameState] = useState(() => {
        const initial = JSON.parse(JSON.stringify(scenarioData.initialState));

        // Ensure executedActionIds exists
        if (!initial.executedActionIds) initial.executedActionIds = [];

        // Initialize Telemetry if not present
        if (!initial.telemetry) {
            initial.telemetry = {
                monitorTime: null,      // Minuto que ligou o monitor
                ecgTime: null,          // Minuto que viu o ECG
                accessTime: null,       // Minuto que pegou acesso
                calciumTime: null,      // Minuto que administrou Gluconato
                treatmentTime: null,    // Minuto da primeira medida de shift
                dialysisRequested: false, // Se pediu diálise
                fatalErrors: 0          // Contador de erros graves
            };
        }

        // Initialize Physiology (Metabolic Engine)
        if (!initial.physiology) {
            initial.physiology = {
                kLevel: 7.2, // Valor inicial (Hardcoded ou vindo do cenário)
                membraneStabilized: false,
                ecgStage: 2  // Baseado no 7.2 inicial
            };
        }

        return initial;
    });
    const [logs, setLogs] = useState([]);

    // Helper to format time
    const formatTime = (minutes) => {
        const hrs = Math.floor(minutes / 60);
        const mins = minutes % 60;
        return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;
    };

    const addLog = (entry) => {
        setLogs(prev => [...prev, entry]);
    };

    // --- METABOLIC ENGINE ---
    const calculatePhysiology = (currentState, addedCost, newActionId) => {
        const { physiology, telemetry, executedActionIds, timeElapsed } = currentState;
        const newTime = timeElapsed + addedCost;

        // 1. Initial K (Baseline)
        const initialK = scenarioData.initialState.labs?.k || 7.2;

        // 2. Deterioration: +0.1 per 10 mins
        // We look at the TOTAL time passed to calculate the drift
        const deterioration = Math.floor(newTime / 10) * 0.1;

        // 3. Treatment Effect (Shifters)
        // Check doses given (including the one just happening if applicable)
        const shifters = ['drug_polarizing', 'drug_salbutamol', 'drug_sorcal', 'drug_lokelma', 'drug_bic'];
        let shifterDoses = executedActionIds.filter(id => shifters.includes(id)).length;

        // Check if current action is a shifter (it hasn't been added to executedActionIds yet in the calling scope usually, 
        // but here we are calculating strictly based on 'currentState' + the 'newAction'. 
        // However, 'executeAction' logic pushes to 'executedActionIds' *inside* the state update. 
        // So we will just trust the passed-in state or check actionId.
        if (shifters.includes(newActionId)) {
            shifterDoses += 1;
        }

        let treatmentDrop = 0;
        // Logic: If we have had a "first treatment time" recorded, and 20 mins have passed SINCE THEN.
        // We use 'telemetry.treatmentTime' which records the FIRST shift measure.
        // If it's null, check if this action sets it.
        let firstTreatmentTime = telemetry.treatmentTime;
        if (firstTreatmentTime === null && shifters.includes(newActionId)) {
            firstTreatmentTime = newTime; // It's happening now
        }

        if (firstTreatmentTime !== null && (newTime - firstTreatmentTime) >= 20) {
            treatmentDrop = shifterDoses * 0.5;
        }

        // 4. Dialysis Effect
        // If Dialysis action is fully completed (cost 60), it drops K drastically.
        // If current action IS dialysis, it finishes at 'newTime'.
        const dialysisJustFinished = (newActionId === 'exam_dialysis' || newActionId === 'proc_dialysis');
        const dialysisPreviouslyDone = executedActionIds.some(id => id === 'exam_dialysis' || id === 'proc_dialysis');
        const isDialyzed = dialysisJustFinished || dialysisPreviouslyDone;


        // 5. Calculate Final K
        let currentK = initialK + deterioration - treatmentDrop;
        if (isDialyzed) currentK = 4.0;

        // Clamp K (min 2.5, max 10 for sanity)
        if (currentK < 2.5) currentK = 2.5;
        if (currentK > 10.0) currentK = 10.0;

        // Round to 1 decimal
        currentK = Math.round(currentK * 10) / 10;


        // 6. Membrane Stabilization
        // If action is calcium, or prev calcium time exists
        const isCalciumAction = newActionId && newActionId.includes('gluconato');
        const hasCalcium = (telemetry.calciumTime !== null) || isCalciumAction;


        // 7. Determine ECG Stage
        /*
            * < 5.5: Stage 0
            * 5.5 - 6.5: Stage 1
            * 6.6 - 7.5: Stage 2
            * 7.6 - 8.5: Stage 3
            * > 8.5: Stage 4
        */
        let stage = 0;
        if (currentK < 5.5) stage = 0;
        else if (currentK <= 6.5) stage = 1;
        else if (currentK <= 7.5) stage = 2;
        else if (currentK <= 8.5) stage = 3;
        else stage = 4;

        // Masking Effect (Calcium)
        // If stabilized and Stage > 1 => Force Stage 1
        if (hasCalcium && stage > 1) {
            stage = 1;
        }

        return {
            kLevel: currentK,
            membraneStabilized: hasCalcium,
            ecgStage: stage
        };
    };


    // We include gameState in dependencies to access the latest state without using the setter callback for side effects
    const executeAction = useCallback((actionId, overrides = {}) => {
        const action = scenarioData.availableActions.find(a => a.id === actionId);

        if (!action) {
            console.error(`Action ${actionId} not found.`);
            return;
        }

        // Access current state directly (safe given the dependency on gameState)
        const currentStatus = gameState.status;
        const currentTimeVal = gameState.timeElapsed;
        const currentSimTime = formatTime(currentTimeVal);

        const actionLabel = overrides.label || action.label;

        // 1. Check Prerequisites
        if (action.requiresIV && !currentStatus.hasIVAccess) {
            addLog({
                time: currentSimTime,
                text: `Falha: ${actionLabel}`,
                consequence: "Requer acesso venoso prévio.",
                type: 'error'
            });

            // Track fatal error (trying to push drug without access)
            setGameState(prev => ({
                ...prev,
                telemetry: {
                    ...prev.telemetry,
                    fatalErrors: (prev.telemetry?.fatalErrors || 0) + 1
                }
            }));

            return; // Stop execution
        }

        // 2. Calculate New State Values
        const newCost = overrides.cost !== undefined ? overrides.cost : (action.cost || 0);
        const newTimeVal = currentTimeVal + newCost;
        const newSimTime = formatTime(newTimeVal);

        // 3. Update Game State
        setGameState(prev => {
            const newState = { ...prev };
            newState.timeElapsed = newTimeVal;

            // Apply specific action effects
            switch (action.id) {
                case 'proc_monitor':
                    newState.status.isMonitored = true;
                    break;
                case 'proc_iv_access':
                    newState.status.hasIVAccess = true;
                    break;
                case 'proc_sonda':
                    newState.status.hasFoley = true;
                    break;
                default:
                    break;
            }

            // --- TRIGGERS LOGIC (Generic) ---
            if (action.triggersVitals) {
                newState.status.isMonitored = true;
            }

            // Track Executed Action
            if (!newState.executedActionIds) newState.executedActionIds = [];
            newState.executedActionIds.push(action.id);

            // --- TELEMETRY LOGIC ---
            // Ensure telemetry object exists (safeguard)
            if (!newState.telemetry) {
                newState.telemetry = {
                    monitorTime: null,
                    ecgTime: null,
                    accessTime: null,
                    calciumTime: null,
                    treatmentTime: null,
                    dialysisRequested: false,
                    fatalErrors: 0
                };
            }

            // Record timestamp if field is null
            const recordTelemetry = (field) => {
                if (newState.telemetry[field] === null) {
                    newState.telemetry[field] = newState.timeElapsed;
                }
            };

            const lowerId = action.id.toLowerCase();

            // Monitor
            if (lowerId === 'proc_monitor' || lowerId === 'monitor') {
                recordTelemetry('monitorTime');
            }
            // ECG
            else if (lowerId === 'proc_ecg12' || lowerId === 'ecg') {
                recordTelemetry('ecgTime');
            }
            // Acesso Venoso
            else if (lowerId === 'proc_iv_access' || lowerId === 'acesso_venoso') {
                recordTelemetry('accessTime');
            }
            // Gluconato
            else if (lowerId.includes('gluconato')) {
                recordTelemetry('calciumTime');
            }
            // Tratamentos (Polarizante, Salbutamol, Sorcal, Lokelma, Bic)
            // Note: checking if "treatment" logic applies
            else if (
                lowerId.includes('polarizante') ||
                lowerId.includes('salbutamol') ||
                lowerId.includes('sorcal') ||
                lowerId.includes('lokelma') ||
                lowerId.includes('bic')
            ) {
                recordTelemetry('treatmentTime');
            }
            // Diálise
            else if (lowerId === 'proc_dialysis' || lowerId === 'dialise') {
                newState.telemetry.dialysisRequested = true;
            }

            // --- METABOLIC ENGINE UPDATE ---
            // We calculate the NEW physiology based on the updated time and actions
            // Note: we pass 'prev' because newState is being mutated and 'executedActionIds' was just pushed to.
            // But 'calculatePhysiology' logic currently manualy adds +1 dose if newActionId matches.
            // To be consistent, let's use the 'newState' which already has the pushed ID.

            // Temporarily use the helper logic adapted for "next state"
            // We need to pass the *newState* to the calculator, but calculatePhysiology expects "currentState" style arguments
            // Let's call it with the "Snapshot of state AFTER action execution"

            const newPhysiology = calculatePhysiology(
                {
                    physiology: prev.physiology || { kLevel: 7.2, membraneStabilized: false, ecgStage: 2 },
                    telemetry: newState.telemetry,
                    executedActionIds: newState.executedActionIds, // Includes the new one
                    timeElapsed: prev.timeElapsed // Pass OLD time, and let function add cost? 
                    // OR Pass NEW time?
                    // Function definition: const calculatePhysiology = (currentState, addedCost, newActionId)
                    // Let's pass PREV state and Add Cost.
                    // But we also need the NEW action ID to be counted.
                },
                newCost,
                action.id
            );

            newState.physiology = newPhysiology;

            // Lab Result Sync (If this action triggers labs, update the visible lab result)
            if (action.triggersLabs) {
                if (!newState.labs) newState.labs = {};
                // Simulate delay? Usually labs result is immediate in this simple model OR delayed.
                // For now, update the 'k' value in labs to match the metabolic engine.
                newState.labs.k = newPhysiology.kLevel;
            }

            return newState;
        });

        // 4. Log Success with User-Requested Structure
        addLog({
            time: newSimTime,
            text: actionLabel,
            consequence: action.resultLog || "Ação realizada.",
            type: 'success'
        });

    }, [gameState, scenarioData]);

    return {
        gameState,
        logs,
        executeAction,
        scenarioData
    };
}
